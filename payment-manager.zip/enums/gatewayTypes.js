const GATEWAY_TYPES = {
  PAYTM: 'paytm',
  BHARATPE: 'bharatPe',
  STRIPE: 'stripe',
  PAYPAL: 'paypal',
  RAZORPAY: 'razorpay',
  SQUARE: 'square',
};

export default GATEWAY_TYPES;
